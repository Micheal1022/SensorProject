#include "msgbox.h"

MsgBox::MsgBox()
{

}

